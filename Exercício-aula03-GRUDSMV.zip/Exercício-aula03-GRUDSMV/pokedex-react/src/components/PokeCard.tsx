import { useEffect, useState } from "react";
import "./PokeCard.css";

type Pokemon = {
  name: string;
  height: number;
  weight: number;
  sprites: {
    front_default: string | null;
  };
  types: Array<{
    type: { name: string };
  }>;
};

type Props = {
  pokemon: Pokemon;
};

export default function PokeCard({ pokemon }: Props) {
  const [favorito, setFavorito] = useState(false);

  useEffect(() => {
    console.log(`Pokémon ${pokemon.name} carregado com sucesso!`);
  }, [pokemon]);

  const toggleFavorito = () => {
    setFavorito(!favorito);
  };

  return (
    <div className="pokecard-container">
      <h3 className="pokecard-name">
        {favorito && "⭐"} {pokemon.name}
      </h3>
      {pokemon.sprites.front_default && (
        <img
          src={pokemon.sprites.front_default}
          alt={pokemon.name}
          className="pokecard-image"
        />
      )}
      <p>
        <strong>Altura:</strong> {pokemon.height * 10} cm
      </p>
      <p>
        <strong>Peso:</strong> {pokemon.weight / 10} kg
      </p>
      <p>
        <strong>Tipos:</strong>{" "}
        {pokemon.types.map((t) => t.type.name).join(" / ")}
      </p>
      <button className="pokecard-fav-button" onClick={toggleFavorito}>
        {favorito ? "Desfavoritar" : "Favoritar"}
      </button>
    </div>
  );
}
